/*
	Spectral by HTML5 UP
	html5up.net | @ajlkn
	Free for personal and commercial use under the CCA 3.0 license (html5up.net/license)
*/



@media (min-width: 35em) {
	.collapsible-expandwhenwide.collapsible .collapsible-content {
			display: block;
		}
		.collapsible-expandwhenwide.collapsible .collapsible-header,
		.collapsible-expandwhenwide.collapsible .collapsible-header button {
			cursor: default;
			background: none;
	}
}